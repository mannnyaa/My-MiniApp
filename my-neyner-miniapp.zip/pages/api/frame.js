import axios from 'axios';

export default async function handler(req, res) {
  const apiKey = process.env.NEYNAR_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'NEYNAR_API_KEY not set' });
  }

  try {
    const response = await axios.post('https://api.neyner.com/frame', req.body, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      }
    });
    res.status(200).json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}